# Ordered Grid Parameters

This file provides information about **Ordered Grid Parameters** as part of the implementing dither algorithms in shaders and generative art code.

It explains the key concepts, historical context, typical characteristics, and use cases relevant to this topic.
